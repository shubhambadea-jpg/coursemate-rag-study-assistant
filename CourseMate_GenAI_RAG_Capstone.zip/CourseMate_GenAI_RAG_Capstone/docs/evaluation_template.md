# Evaluation Template

Fill this in after testing against the official course dataset. Do not report expected values as measured results.

| ID | Question | Expected source / evidence | Retrieved evidence relevant? (Y/N) | Answer grounded? (Y/N) | Notes |
|---|---|---|---|---|---|
| Q1 | Replace with a dataset-based question | | | | |
| Q2 | Replace with a dataset-based question | | | | |
| Q3 | Replace with a dataset-based question | | | | |
| Q4 | Replace with a dataset-based question | | | | |
| Q5 | Replace with a dataset-based question | | | | |
| Q6 | Replace with a dataset-based question | | | | |
| Q7 | Replace with a dataset-based question | | | | |
| Q8 | Replace with a dataset-based question | | | | |
| Q9 | Replace with a dataset-based question | | | | |
| Q10 | Replace with a dataset-based question | | | | |

## Metrics
- Retrieval hit rate = number of questions with relevant evidence in top-k / total questions.
- Grounded answer rate = number of answers fully supported by retrieved evidence / total answerable questions.
- Abstention correctness = number of unanswerable questions where the system admits missing evidence / total unanswerable questions.

Report sample size, top-k, whether Gemini was enabled, and any failures.
