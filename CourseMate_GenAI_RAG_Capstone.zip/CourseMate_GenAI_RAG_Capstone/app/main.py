import os
import sys
from pathlib import Path
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app.rag_engine import RAGEngine
from app.document_loader import extract_text

st.set_page_config(page_title="CourseMate | GenAI Study Assistant", page_icon="📚", layout="wide")
st.title("📚 CourseMate")
st.subheader("A document-grounded study assistant powered by Retrieval-Augmented Generation (RAG)")
st.caption("Upload course notes or PDFs, ask questions, and inspect the source passages used.")

if "engine" not in st.session_state:
    st.session_state.engine = RAGEngine()
if "loaded_names" not in st.session_state:
    st.session_state.loaded_names = set()
if "history" not in st.session_state:
    st.session_state.history = []

with st.sidebar:
    st.header("Knowledge base")
    uploads = st.file_uploader("Add documents", type=["pdf", "txt", "md"], accept_multiple_files=True)
    if st.button("Index uploaded documents", type="primary", use_container_width=True):
        if not uploads:
            st.warning("Choose at least one file first.")
        else:
            docs, errors = [], []
            for upload in uploads:
                if upload.name in st.session_state.loaded_names:
                    continue
                try:
                    text = extract_text(upload.name, upload.getvalue())
                    if not text.strip():
                        errors.append(f"{upload.name}: no extractable text (scanned PDFs need OCR).")
                    else:
                        docs.append({"source": upload.name, "text": text})
                except Exception as exc:
                    errors.append(f"{upload.name}: {exc}")
            count = st.session_state.engine.add_documents(docs)
            st.session_state.loaded_names.update(d["source"] for d in docs)
            if docs:
                st.success(f"Indexed {len(docs)} document(s), creating {count} text chunks.")
            for err in errors:
                st.error(err)
    st.markdown("---")
    st.caption(f"Indexed files: {len(st.session_state.loaded_names)}")
    st.caption(f"Text chunks: {len(st.session_state.engine.chunks)}")
    api_key = st.text_input("Gemini API key (optional)", type="password",
                            help="Used only for answer generation. Leave blank for retrieval-only mode.")
    top_k = st.slider("Number of source chunks", min_value=1, max_value=6, value=4)
    if st.button("Clear knowledge base", use_container_width=True):
        st.session_state.engine = RAGEngine()
        st.session_state.loaded_names = set()
        st.session_state.history = []
        st.rerun()

left, right = st.columns([1.35, 1])
with left:
    st.markdown("### Ask your notes")
    question = st.text_area("Question", placeholder="Example: Explain the main stages of a RAG pipeline.", height=100)
    ask = st.button("Find answer", type="primary", disabled=not bool(st.session_state.engine.chunks))
    if not st.session_state.engine.chunks:
        st.info("Upload and index a PDF, TXT, or Markdown file from the sidebar to begin.")
    if ask and question.strip():
        with st.spinner("Retrieving relevant passages and preparing an answer..."):
            result = st.session_state.engine.answer(question.strip(), api_key=api_key, top_k=top_k)
        st.session_state.history.insert(0, {"question": question.strip(), **result})
    for item in st.session_state.history:
        with st.container(border=True):
            st.markdown(f"**Question:** {item['question']}")
            st.markdown(item["answer"])
            if item["sources"]:
                with st.expander("Inspect retrieved sources"):
                    for source in item["sources"]:
                        st.markdown(f"**{source['source']} · chunk {source['chunk_id']} · relevance {source['score']:.3f}**")
                        st.write(source["text"])

with right:
    st.markdown("### How it works")
    st.markdown("""
1. **Load** PDF, TXT, or Markdown course material.
2. **Chunk** long text into overlapping passages.
3. **Retrieve** relevant chunks with TF-IDF similarity.
4. **Generate** a grounded answer with Gemini when an API key is supplied.
5. **Inspect** the retrieved evidence for transparency.
""")
    st.warning("Answers depend on the uploaded material. Verify important facts against your course resources.")
    st.markdown("### Demo prompts")
    st.markdown("- What are the key concepts in this document?\n- Summarize the main process described.\n- What evidence supports the author's conclusion?\n- Which details are not covered by these notes?")
