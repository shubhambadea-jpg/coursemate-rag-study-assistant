"""Document extraction helpers for PDF, TXT, and Markdown uploads."""
from pathlib import Path
from io import BytesIO

def extract_text(filename: str, file_bytes: bytes) -> str:
    suffix = Path(filename).suffix.lower()
    if suffix == ".pdf":
        from pypdf import PdfReader
        reader = PdfReader(BytesIO(file_bytes))
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    if suffix in {".txt", ".md"}:
        return file_bytes.decode("utf-8", errors="replace")
    raise ValueError(f"Unsupported file type: {suffix}. Upload PDF, TXT, or MD.")
