from app.rag_engine import RAGEngine, split_text

def test_split_text_empty():
    assert split_text("") == []

def test_split_text_overlap_and_coverage():
    text = ("Alpha beta gamma. " * 120).strip()
    chunks = split_text(text, chunk_size=300, overlap=50)
    assert len(chunks) > 1
    assert all(chunks)
    assert "Alpha" in chunks[0]
    assert "gamma" in chunks[-1]

def test_retrieval_finds_relevant_document():
    engine = RAGEngine()
    engine.add_documents([
        {"source": "rag.txt", "text": "Retrieval augmented generation retrieves relevant passages before generating an answer."},
        {"source": "cooking.txt", "text": "Pasta can be boiled in salted water and served with tomato sauce."}
    ])
    results = engine.retrieve("How does retrieval augmented generation work?", top_k=2)
    assert results
    assert results[0]["source"] == "rag.txt"

def test_unknown_query_returns_no_sources():
    engine = RAGEngine()
    engine.add_documents([{"source": "a.txt", "text": "Apples are fruits."}])
    assert engine.retrieve("quantum spacecraft engines", top_k=3) == []
