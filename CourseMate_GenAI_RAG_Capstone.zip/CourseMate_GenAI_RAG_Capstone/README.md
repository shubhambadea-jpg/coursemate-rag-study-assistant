# CourseMate — GenAI Study Assistant with RAG

**Capstone project | From Tokens to Transformers: GenAI × LLM Mastery | IIT Guwahati**

CourseMate is a small, transparent study assistant that answers questions using a user's uploaded course documents. It demonstrates a complete Retrieval-Augmented Generation (RAG) workflow: document ingestion, chunking, retrieval, grounded generation, source inspection, and a safe fallback when an LLM is unavailable.

## Why this project?
General-purpose chatbots can answer from prior training and may hallucinate. CourseMate first retrieves evidence from the learner's own material. When a Gemini API key is provided, the LLM is instructed to answer only from that context and cite the source filename/chunk. Without a key, the app honestly displays the best matching passages instead of fabricating an answer.

## Features
- Upload PDF, TXT, and Markdown notes.
- Overlapping chunking for long documents.
- TF-IDF + cosine-similarity retrieval (no vector database or paid embedding API required).
- Optional Gemini 2.5 Flash answer generation.
- Source passages, filenames, chunk IDs, and relevance scores.
- Prompt-injection-aware instruction: retrieved text is treated as untrusted reference content.
- Clear knowledge base and multi-question session history.
- Unit tests for chunking and retrieval.

## Architecture

```text
PDF / TXT / MD
      |
      v
Text extraction (pypdf / UTF-8)
      |
      v
Chunking (900 characters, 150 overlap)
      |
      v
TF-IDF vectorization + cosine similarity
      |
      v
Top-k relevant passages
      |
      +-----------------------+
      |                       |
      v                       v
Gemini 2.5 Flash         Retrieval-only fallback
(grounded prompt)        (show evidence, no invention)
      |                       |
      +-----------+-----------+
                  v
        Answer + source inspection
```

## Run locally

### 1. Install Python
Use Python 3.10 or newer.

### 2. Clone the repository
```bash
git clone https://github.com/YOUR-USERNAME/coursemate-rag-study-assistant.git
cd coursemate-rag-study-assistant
```

### 3. Create an environment and install dependencies
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

### 4. Launch the app
```bash
streamlit run app/main.py
```
Open the local URL printed in the terminal, usually `http://localhost:8501`.

### 5. Optional: enable Gemini generation
Create a Gemini API key in Google AI Studio, then paste it into the password field in the app sidebar. The key is used only for generation. **Never commit API keys to GitHub.** Without a key, retrieval and source inspection still work.

## How to use
1. Open the app.
2. Upload one or more PDF/TXT/MD documents.
3. Click **Index uploaded documents**.
4. Type a question grounded in those documents.
5. Click **Find answer**.
6. Expand **Inspect retrieved sources** to check the evidence.
7. If answers seem weak, try a more specific question or upload a better source.

## Tests
```bash
pytest -q
```

## Evaluation plan
Evaluate with at least 10 questions based on the uploaded dataset:
- **Retrieval relevance:** does at least one of the top-k passages contain the answer?
- **Groundedness:** are answer claims supported by retrieved text?
- **Abstention:** does the system admit when the answer is not in the knowledge base?
- **Usability:** can a new user upload a document and get an answer without instructions?

A starter evaluation template is in [`docs/evaluation_template.md`](docs/evaluation_template.md). Add the official course dataset and use it to create the final question set before submission.

## Limitations
- TF-IDF is lexical retrieval; it can miss semantically related wording. A production version could use sentence-transformer embeddings and FAISS/Chroma.
- Scanned/image-only PDFs need OCR and are not handled here.
- Chunking is character-based, not token-based.
- Model output may still be wrong; always inspect the sources.
- The API key is entered in the local UI; do not expose a deployed app publicly with an unrestricted key field.

## Future improvements
- Replace TF-IDF with dense embeddings + FAISS/Chroma.
- Add OCR for scanned PDFs.
- Add retrieval metrics such as Recall@k and MRR.
- Add a small agent workflow that routes between summarization, question answering, and quiz generation.
- Add authentication and per-user document isolation for deployment.

## Repository structure
```text
coursemate-rag-study-assistant/
├── app/
│   ├── main.py
│   ├── rag_engine.py
│   └── document_loader.py
├── data/sample_docs/
├── docs/
│   ├── project_report.pdf
│   └── evaluation_template.md
├── tests/
├── requirements.txt
├── .env.example
└── README.md
```

## Dataset note
The Unstop event page mentions a dataset link, but the URL was not included in the information used to prepare this repository. Before final submission, download the official dataset from the event page, add it locally for evaluation (respect its licence and privacy terms), and document the dataset name/source in the report. Do not commit sensitive or restricted data.

## Capstone deliverables checklist
- [ ] Replace `YOUR-USERNAME` with your GitHub username in the clone command.
- [ ] Add the official dataset details and 10–20 evaluation questions.
- [ ] Run the app and capture 2–3 screenshots for the README.
- [ ] Run `pytest -q`.
- [ ] Update the report with actual evaluation results (do not invent metrics).
- [ ] Ensure the repository is public if the organizers need to access it.
- [ ] Submit the GitHub URL and `docs/project_report.pdf` on Unstop before **1 November 2026, 11:59 PM IST** (as shown on your event page).
